
const hamburgerButton = document.querySelector('.hamburger_button');
const sidebar = document.querySelector('.frame2');

hamburgerButton.addEventListener('click', () => {
 
  sidebar.classList.toggle('show');
});